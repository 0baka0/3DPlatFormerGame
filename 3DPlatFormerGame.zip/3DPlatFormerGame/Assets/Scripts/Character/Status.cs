using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Status : MonoBehaviour
{
    [Header("Walk, Run Speed")]
    public float walkSpeed; // �ȱ� �ӵ�
    public float runSpeed;  // �޸��� �ӵ�
}
